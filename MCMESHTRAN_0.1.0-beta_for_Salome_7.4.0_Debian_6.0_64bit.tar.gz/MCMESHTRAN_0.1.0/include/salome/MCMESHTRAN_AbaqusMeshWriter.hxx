#ifndef MCMESHTRAN_ABAQUSMESHWRITER_HXX
#define MCMESHTRAN_ABAQUSMESHWRITER_HXX

#include <fstream>
#include <QString>
#include <vector>
#include <QMap>
#include <MEDCouplingUMesh.hxx>
#include <MEDCouplingMemArray.hxx>

using namespace std;
using namespace ParaMEDMEM;


class MCMESHTRAN_AbaqusMeshWriter
{
public:
    MCMESHTRAN_AbaqusMeshWriter();
    ~MCMESHTRAN_AbaqusMeshWriter();

    void    setMeshes(vector <const MEDCouplingUMesh *> & MeshList) ;
    bool    exportFile (const QString & OutFileName);


private:
    vector <const MEDCouplingUMesh *> myMeshList;
    QString myOutFileName;
    ofstream myOutFile;
    QMap <int, QString > ElementType;



};

#endif // MCMESHTRAN_ABAQUSMESHWRITER_HXX
