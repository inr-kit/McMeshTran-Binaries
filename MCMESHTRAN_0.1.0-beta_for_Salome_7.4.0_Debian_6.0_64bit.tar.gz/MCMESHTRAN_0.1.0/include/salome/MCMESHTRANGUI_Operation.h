#ifndef MCMESHTRANGUI_OPERATION_H
#define MCMESHTRANGUI_OPERATION_H
#include <LightApp_Operation.h>
#include "MCMESHTRANGUI_Dialogs.h"

class MCMESHTRANGUI_DataModel;
class MCMESHTRANGUI;

class MCMESHTRANGUI_Operation: public LightApp_Operation
{
    Q_OBJECT

public:
    MCMESHTRANGUI_Operation();
    virtual ~MCMESHTRANGUI_Operation();

protected:
  virtual void startOperation();
  virtual void abortOperation();
  virtual void commitOperation();
  virtual void finish();

  MCMESHTRANGUI_DataModel*   dataModel() const;
  MCMESHTRANGUI*             MCMESHTRANGUIModule() const;

protected slots:
  virtual void onOk();
  virtual void onApply();
  virtual void onClose();

protected:
//  LightApp_Dialog*  myDlg;
  MCMESHTRANGUI_TemplateDlg * myDlg;
  QString           LastName;

};

#endif // MCMESHTRANGUI_OPERATION_H
